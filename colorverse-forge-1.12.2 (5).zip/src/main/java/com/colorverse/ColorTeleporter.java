package com.colorverse;

import net.minecraft.entity.Entity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.Teleporter;
import net.minecraft.world.World;
import net.minecraft.world.WorldServer;

public class ColorTeleporter extends Teleporter {
    private final WorldServer ws;

    public ColorTeleporter(WorldServer ws) {
        super(ws);
        this.ws = ws;
    }

    @Override
    public void placeInPortal(Entity entity, float yaw) { place(entity); }

    @Override
    public boolean placeInExistingPortal(Entity entity, float yaw) { place(entity); return true; }

    @Override
    public void placeEntity(World world, Entity entity, float yaw) { place(entity); }

    private void place(Entity e) {
        int dim = ws.provider.getDimension();
        BlockPos pos;
        if (dim >= ColorVerse.BASE_ID && dim < ColorVerse.BASE_ID + 16) {
            int idx = dim - ColorVerse.BASE_ID;
            pos = new BlockPos(0, 64, 0);
            // geri dönüş portalı
            ws.setBlockState(new BlockPos(3, 63, 0), Registry.PORTALS[idx].getDefaultState());
        } else {
            pos = ws.getTopSolidOrLiquidBlock(ws.getSpawnPoint());
        }
        e.motionX = 0; e.motionY = 0; e.motionZ = 0;
        e.fallDistance = 0;
        e.setLocationAndAngles(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5, e.rotationYaw, e.rotationPitch);
    }
}
