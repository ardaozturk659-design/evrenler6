package com.colorverse;

import net.minecraft.block.Block;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBlock;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;

@Mod.EventBusSubscriber(modid = ColorVerse.MODID)
public class Registry {
    public static final ColorPortalBlock[] PORTALS = new ColorPortalBlock[16];

    static {
        for (int i = 0; i < 16; i++) PORTALS[i] = new ColorPortalBlock(i);
    }

    @SubscribeEvent
    public static void registerBlocks(RegistryEvent.Register<Block> e) {
        e.getRegistry().registerAll(PORTALS);
    }

    @SubscribeEvent
    public static void registerItems(RegistryEvent.Register<Item> e) {
        for (ColorPortalBlock b : PORTALS) {
            ItemBlock ib = new ItemBlock(b);
            ib.setRegistryName(b.getRegistryName());
            e.getRegistry().register(ib);
        }
    }
}
