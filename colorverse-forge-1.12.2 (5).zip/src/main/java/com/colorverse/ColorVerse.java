package com.colorverse;

import net.minecraft.item.EnumDyeColor;
import net.minecraft.world.DimensionType;
import net.minecraftforge.common.DimensionManager;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;

@Mod(modid = ColorVerse.MODID, name = "ColorVerse", version = "1.0", acceptedMinecraftVersions = "[1.12.2]")
public class ColorVerse {
    public static final String MODID = "colorverse";
    public static final int BASE_ID = 100; // evren ID'leri: 100..115
    public static final DimensionType[] TYPES = new DimensionType[16];

    @Mod.EventHandler
    public void preInit(FMLPreInitializationEvent event) {
        for (int i = 0; i < 16; i++) {
            String name = EnumDyeColor.byMetadata(i).getName();
            TYPES[i] = DimensionType.register("ColorVerse_" + name, "_cv_" + name, BASE_ID + i, ColorWorldProvider.class, false);
            DimensionManager.registerDimension(BASE_ID + i, TYPES[i]);
        }
    }
}
