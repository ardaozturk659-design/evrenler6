package com.colorverse;

import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.item.Item;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.relauncher.Side;

@Mod.EventBusSubscriber(value = Side.CLIENT, modid = ColorVerse.MODID)
public class ClientEvents {
    @SubscribeEvent
    public static void models(ModelRegistryEvent e) {
        for (ColorPortalBlock b : Registry.PORTALS) {
            ModelLoader.setCustomModelResourceLocation(Item.getItemFromBlock(b), 0,
                    new ModelResourceLocation(b.getRegistryName(), "inventory"));
        }
    }
}
