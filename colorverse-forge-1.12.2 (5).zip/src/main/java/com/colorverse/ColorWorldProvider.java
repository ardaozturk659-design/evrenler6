package com.colorverse;

import net.minecraft.entity.player.EntityPlayerMP;
import net.minecraft.init.Biomes;
import net.minecraft.item.EnumDyeColor;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.DimensionType;
import net.minecraft.world.WorldProvider;
import net.minecraft.world.biome.BiomeProviderSingle;
import net.minecraft.world.gen.IChunkGenerator;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

public class ColorWorldProvider extends WorldProvider {
    private int idx() { return getDimension() - ColorVerse.BASE_ID; }

    @Override
    public DimensionType getDimensionType() { return ColorVerse.TYPES[idx()]; }

    @Override
    protected void init() {
        this.hasSkyLight = true;
        this.biomeProvider = new BiomeProviderSingle(Biomes.PLAINS);
    }

    @Override
    public IChunkGenerator createChunkGenerator() { return new ColorChunkGenerator(world, idx()); }

    @Override
    public boolean canRespawnHere() { return false; }

    @Override
    public int getRespawnDimension(EntityPlayerMP player) { return 0; }

    @Override
    @SideOnly(Side.CLIENT)
    public Vec3d getFogColor(float celestialAngle, float partialTicks) {
        float[] c = EnumDyeColor.byMetadata(idx()).getColorComponentValues();
        return new Vec3d(c[0], c[1], c[2]);
    }
}
