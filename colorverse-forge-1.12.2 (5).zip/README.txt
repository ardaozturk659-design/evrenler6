KURULUM (Forge 1.12.2 MDK ile)
1) Forge 1.12.2 MDK'yi indir ve ac.
2) Bu zipteki src/main klasorunun icindekileri MDK'nin src/main klasorune kopyala.
3) gradlew build -> build/libs icinde .jar cikar, mods klasorune at.
   (test icin: gradlew runClient)

KULLANIM
- Yaratici modda "Insaat Bloklari" sekmesinde 16 renkli Portal blogu var.
- Portal blogunun ustune bas -> o rengin evrenine isinlanirsin (ID 100-115).
- Evrende (3,63,0) konumunda geri donus portali olusur; ustune basinca overworld'e donersin.
- Komutla gecis: /forge tpx 100 (beyaz) ... 115 (siyah)
